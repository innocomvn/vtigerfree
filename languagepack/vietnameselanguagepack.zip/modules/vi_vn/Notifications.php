<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

$languageStrings = array(
	'Notifications' => 'Thông báo',
	'SINGLE_Notifications' => 'Thông báo',
	'LBL_BLOCK_GENERAL_INFORMATION' => '',
	'LBL_BLOCK_SYSTEM_INFORMATION' => '',
	'LBL_DESCRIPTION' => 'Mô tả',
	'LBL_RELATE_TO' => 'Liên quan',
	'LBL_NOTIFICATION_STATUS' => 'Trạng thái',
	'LBL_FROM_USER' => 'Người thông báo',
	'LBL_NOTINUMBER' => 'Mã số',
	'View History' => '',
	'EMAILMaker' => '',
	'Workflows' => '',
	'LBL_NOTIFICATION_CSS' => 'notification css',
	'LBL_NOTIFICATION_JS' => 'notification js',
	'LBL_TIMEAGO_JS' => 'timeagojs',
	'Send Emails with EMAILMaker' => '',
	'LBL_STATUS' => 'Trạng thái',
	'LBL_NOTI_NUMBER' => 'Noti ID',
	'LBL_NOTIFICATION_NUMBER' => '',

);

?>
