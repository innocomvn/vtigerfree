<?php
/* ********************************************************************************
 * The content of this file is subject to the VTE Notepad ("License");
 * You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is VTExperts.com
 * Portions created by VTExperts.com. are Copyright(C) VTExperts.com.
 * All Rights Reserved.
 * ****************************************************************************** */

$languageStrings = array(
    'VTENotepad' => 'VTE Notepad',
    'VTE Notepad' => 'VTE Notepad',
    'LBL_SUCCESSFUL' => 'Successful',
    'LBL_FAILURE' => 'Failure',
    'Last saved' => 'Last saved',
);

$jsLanguageStrings = array(
);