<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Stefan Warnat <support@stefanwarnat.de>
 * Date: 13.02.14 17:51
 * You must not use this file without permission.
 */
//require('Settings/RedooReports.php');

$languageStrings = array_merge($languageStrings, array(
    'RedooReports' => 'Flex Reports',
    'LBL_LICENSE_MANAGER'   => 'License management',
    'LBL_LICENSE_IS'        => 'License is',
    'LBL_LICENSE_STATE'     => 'License version',
    'LBL_REVALIDATE_LICENSE' => 'Revalidate License',
    'LBL_REMOVE_LICENSE'    => 'remove License',
    'LBL_ACTIVE'=>'Active',
    'LBL_INACTIVE'=>'Inactive',
));
$jsLanguageStrings = array_merge($jsLanguageStrings, array(

));

