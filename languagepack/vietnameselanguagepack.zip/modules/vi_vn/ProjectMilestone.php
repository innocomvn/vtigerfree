<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	'LBL_ADD_RECORD' => 'Thêm Mốc dự án',
	'LBL_PROJECT_MILESTONE_INFORMATION' => 'Chi tiết Mốc dự án',
	'LBL_RECORDS_LIST' => 'Danh sách Mốc dự án',
	'Milestone Date' => 'Ngày kết thúc',
	'Project Milestone Name' => 'Tên Mốc dự án',
	'Project Milestone No' => 'Mã bản ghi',
	'SINGLE_ProjectMilestone' => 'Mốc dự án',
    'LBL_PROJECTS_LIST' => 'Danh sách dự án',
    'LBL_TASKS_LIST' => 'Danh sách Nhiệm vụ',
    'LBL_MILESTONES_LIST' => 'Danh sách Mốc dự án',
	'description' => 'Mô tả',
	'Related to' => 'Liên quan tới',
	'description' => 'Mô tả',

);
