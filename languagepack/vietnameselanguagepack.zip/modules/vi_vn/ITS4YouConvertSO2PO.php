<?php

/* * *******************************************************************************
 * The content of this file is subject to the DeliveryNotes4You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

$languageStrings = array(
    "LBL_TOBE_CREATED_PO" => "Purchase Order(s) to be created",
    "LBL_CREATE_PO" => "Create Purchase Order(s)",
    "HEAD_ORDERED_QTY" => "Order quantity",
    "LBL_NO_VENDOR" => "without Vendor",
    "ALERT_NEW_PO_NUMBER" => "new Purchase Order(s) was(were) created automatically in background. See related list.",
    "LBL_AUTOMATICALLY" => "(automatically)",
    "LBL_MANUALLY" => "(manually)"
);
?>