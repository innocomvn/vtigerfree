<?php
 
$languageStrings = array(
	'FromDb' => 'Generate from Database',
);
$jsLanguageStrings = Array(
	'Translations' => 'Translations',

);