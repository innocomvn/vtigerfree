<?php
$languageStrings = array(
'Khách hàng'	=>	'Khách hàng',
'Nội bộ'	=>	'Nội bộ',
'Đã tư vấn'	=>	'Đã tư vấn',
'Chấp nhận tư vấn'	=>	'Chấp nhận tư vấn',
'Tư vấn không thành công'	=>	'Tư vấn không thành công',
'Chấp nhận báo giá'	=>	'Chấp nhận báo giá',
'Từ chối báo giá'	=>	'Từ chối báo giá',
'Đang tạo Order'	=>	'Đang tạo Order',
'W-Cần xếp lịch thực hiện'	=>	'W-Cần xếp lịch thực hiện',
'Thực hiện xong - Chờ hoàn thành thủ tục'	=>	'Thực hiện xong - Chờ hoàn thành thủ tục',
'Chatbox'	=>	'Chatbox',
'Email thương hiệu'	=>	'Email thương hiệu',
'Bộ nhận diện thương hiệu'	=>	'Bộ nhận diện thương hiệu',
'Quảng cáo'	=>	'Quảng cáo',
'SSL'	=>	'SSL',
'Trruy xuất nguồn gốc'	=>	'Trruy xuất nguồn gốc',
);