<?php
/*********************************************************************************
 * The content of this file is subject to the Dynamic Fields 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * *******************************************************************************/

$languageStrings = Array (
    "ITS4YouDynamicFields" => "Dynamic Fields 4 You",
    "LBL_INVALID_KEY" => "Invalid license key! Please contact the vendor of Dynamic Fields 4 You.",
    "LBL_QUICK_EDITABLE" => "Quick Editable",
    'LBL_APPLY' => 'Apply',
    "COPYRIGHT" => "IT-Solutions4You",    
    "LBL_LICENSE" => "License settings",
    "LBL_LICENSE_DESC" => "Manage all settings related to your license",
    "LBL_UPGRADE" => "Upgrade",    
    "LBL_UNINSTALL" => "Uninstall",
    "LBL_UNINSTALL_DESC" => "Remove Dynamic Fields 4 You completely from your vTiger.",
);

$jsLanguageStrings = array(
   
);